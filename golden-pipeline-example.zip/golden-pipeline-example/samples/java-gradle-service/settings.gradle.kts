rootProject.name = "pricing-service"
